// main.cpp
// author: corentin mercier
//

// remove comments on lines 14-18 for the second question

#include <iostream>
#include <string>

using namespace std;

class myClass
{
  string myString = "hello";
  /*myClass(int a)
  {
    std::cout << "test";
  }*/
};

int main()
{
  myClass object;
  return 0;
}
